function y = vecsum(x)

y = sum(x(:));

return