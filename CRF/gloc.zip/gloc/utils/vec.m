function y = vec(x)
y = x(:);
return;